import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'screens/conversations_screen.dart';
import 'screens/privacy_screen.dart';
import 'services/api_service.dart';
import 'services/app_state.dart';
import 'services/db_service.dart';
import 'services/discovery_service.dart';
import 'services/settings_store.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EonApp());
}

class EonApp extends StatefulWidget {
  const EonApp({super.key});

  @override
  State<EonApp> createState() => _EonAppState();
}

class _EonAppState extends State<EonApp> {
  late final AppState _app = AppState(
    store: SettingsStore(),
    discovery: DiscoveryService(),
    api: ApiService(),
    db: DbService(),
  )..init();

  @override
  void dispose() {
    _app.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<AppState>.value(
      value: _app,
      child: Consumer<AppState>(
        builder: (context, app, _) {
          Widget home;
          if (!app.loaded) {
            home = const Scaffold(body: Center(child: CircularProgressIndicator()));
          } else if (!app.settings.privacySeen) {
            home = const PrivacyScreen(); // lần mở đầu tiên
          } else {
            home = const ConversationsScreen();
          }
          return MaterialApp(
            title: 'EON GPT',
            debugShowCheckedModeBanner: false,
            themeMode: app.settings.themeMode,
            theme: ThemeData(
              useMaterial3: true,
              colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3F51B5)),
            ),
            darkTheme: ThemeData(
              useMaterial3: true,
              colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF3F51B5), brightness: Brightness.dark),
            ),
            locale: const Locale('vi'),
            supportedLocales: const [Locale('vi')],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: home,
          );
        },
      ),
    );
  }
}
