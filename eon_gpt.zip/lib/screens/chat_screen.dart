import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/message.dart';
import '../services/app_state.dart';
import '../services/chat_controller.dart';
import '../widgets/message_bubble.dart';
import '../widgets/status_bar.dart';
import 'settings_screen.dart';

/// Màn hình chat. [conversationId] = null nghĩa là hội thoại mới.
class ChatScreen extends StatefulWidget {
  final String? conversationId;
  const ChatScreen({super.key, this.conversationId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final ChatController c;
  final _input = TextEditingController();

  @override
  void initState() {
    super.initState();
    c = ChatController(context.read<AppState>(), widget.conversationId)..load();
  }

  @override
  void dispose() {
    c.dispose();
    _input.dispose();
    super.dispose();
  }

  void _send() {
    final t = _input.text;
    if (t.trim().isEmpty) return;
    _input.clear();
    c.send(t);
  }

  void _toast(String text) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _rate(Message m, String rating) async {
    final err = await c.rate(m, rating);
    if (!mounted) return;
    _toast(err ?? 'Đã gửi phản hồi. Cảm ơn bạn!');
  }

  Future<void> _correct(Message m) async {
    if (!m.saved) {
      _toast('Câu này chưa được lưu trên máy chủ. Hãy bật "Cho phép lưu hội thoại" trong Cài đặt rồi trò chuyện tiếp.');
      return;
    }
    final init = m.content.length > 4000 ? m.content.substring(0, 4000) : m.content;
    final ctl = TextEditingController(text: init);
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sửa câu trả lời'),
        content: SizedBox(
          width: double.maxFinite,
          child: TextField(
            controller: ctl,
            autofocus: true,
            minLines: 4,
            maxLines: 10,
            maxLength: 4000,
            decoration: const InputDecoration(
              hintText: 'Viết câu trả lời đúng mà EON nên nói…',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text), child: const Text('Gửi')),
        ],
      ),
    );
    if (text == null || !mounted) return;
    final err = await c.correct(m, text);
    if (!mounted) return;
    _toast(err ?? 'Đã gửi câu trả lời đúng. Cảm ơn bạn!');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final showError = c.error != null && !c.busy;
        final count = c.messages.length + (c.busy ? 1 : 0) + (showError ? 1 : 0);
        return Scaffold(
          appBar: AppBar(
            title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            actions: [
              IconButton(
                tooltip: 'Cài đặt',
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
              ),
            ],
          ),
          body: Column(
            children: [
              const ServerStatusBar(),
              Expanded(
                child: count == 0
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.all(24),
                          child: Text('Hãy nhắn gì đó cho EON để bắt đầu.',
                              textAlign: TextAlign.center),
                        ),
                      )
                    : ListView.builder(
                        reverse: true, // mới nhất ở dưới cùng, tự giữ ở cuối khi chữ chạy
                        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                        itemCount: count,
                        itemBuilder: (ctx, index) {
                          final i = count - 1 - index; // vị trí thật (0 = cũ nhất)
                          if (i < c.messages.length) {
                            final m = c.messages[i];
                            return MessageBubble(
                              key: ValueKey(m.id ?? 'm$i'),
                              message: m,
                              isLast: i == c.messages.length - 1,
                              busy: c.busy,
                              onRegenerate: c.regenerate,
                              onRate: (r) => _rate(m, r),
                              onCorrect: () => _correct(m),
                            );
                          }
                          if (c.busy) {
                            return StreamingBubble(text: c.streaming, notice: c.notice);
                          }
                          return _ErrorBanner(
                            text: c.error!,
                            onRetry: c.regenerate,
                            onSettings: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const SettingsScreen())),
                          );
                        },
                      ),
              ),
              _buildInput(context),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInput(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 8, 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: TextField(
                controller: _input,
                minLines: 1,
                maxLines: 6,
                keyboardType: TextInputType.multiline,
                textCapitalization: TextCapitalization.sentences,
                inputFormatters: [LengthLimitingTextInputFormatter(6000)],
                decoration: InputDecoration(
                  hintText: 'Nhắn cho EON…',
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 6),
            c.busy
                ? IconButton.filled(
                    tooltip: 'Dừng',
                    icon: const Icon(Icons.stop),
                    onPressed: c.stop,
                  )
                : IconButton.filled(
                    tooltip: 'Gửi',
                    icon: const Icon(Icons.send),
                    onPressed: _send,
                  ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String text;
  final VoidCallback onRetry;
  final VoidCallback onSettings;
  const _ErrorBanner({required this.text, required this.onRetry, required this.onSettings});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      color: cs.errorContainer,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(text, style: TextStyle(color: cs.onErrorContainer)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                FilledButton.tonalIcon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('Thử lại'),
                ),
                TextButton(onPressed: onSettings, child: const Text('Cài đặt')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
