import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';

/// Màn hình giải thích quyền riêng tư — hiện ở lần mở app đầu tiên.
class PrivacyScreen extends StatefulWidget {
  const PrivacyScreen({super.key});

  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  bool _allow = false; // mặc định TẮT

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ListView(
                  children: [
                    const SizedBox(height: 12),
                    Icon(Icons.privacy_tip_outlined, size: 48, color: cs.primary),
                    const SizedBox(height: 12),
                    Text('Chào mừng đến với EON GPT',
                        style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 16),
                    const _Point(Icons.lock_outline,
                        'Mặc định, hội thoại của bạn KHÔNG được lưu trên máy chủ. Chúng chỉ nằm trong điện thoại này.'),
                    const _Point(Icons.model_training,
                        'Chỉ khi bạn bật công tắc bên dưới, hội thoại mới được lưu để cải thiện mô hình EON.'),
                    const _Point(Icons.visibility_off_outlined,
                        'Thông tin cá nhân sẽ được ẩn trên máy chủ, nhưng bạn vẫn nên tránh nhập thông tin nhạy cảm (mật khẩu, số thẻ, địa chỉ nhà...).'),
                    const _Point(Icons.delete_outline,
                        'Bạn có thể xóa dữ liệu bất cứ lúc nào: Cài đặt → "Xóa dữ liệu của tôi".'),
                    const _Point(Icons.shield_outlined,
                        'App không có công cụ theo dõi, quảng cáo hay phân tích. Chỉ kết nối HTTPS.'),
                    const SizedBox(height: 8),
                    Card(
                      child: SwitchListTile(
                        title: const Text('Cho phép lưu hội thoại để cải thiện EON'),
                        subtitle: const Text('Có thể đổi lại trong Cài đặt'),
                        value: _allow,
                        onChanged: (v) => setState(() => _allow = v),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () =>
                      context.read<AppState>().completePrivacy(allowSave: _allow),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 6),
                    child: Text('Đã hiểu, tiếp tục'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Point extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Point(this.icon, this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 22),
            const SizedBox(width: 12),
            Expanded(child: Text(text, style: const TextStyle(height: 1.4))),
          ],
        ),
      );
}
