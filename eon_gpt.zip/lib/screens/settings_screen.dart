import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';
import '../services/auth_service.dart';
import '../widgets/status_bar.dart';

/// Cài đặt: địa chỉ máy chủ, khóa API, tham số sinh chữ, quyền riêng tư, giao diện.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _url;
  late final TextEditingController _key;
  bool _showKey = false;
  bool _deleting = false;
  bool _signing = false;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>().settings;
    _url = TextEditingController(text: s.manualUrl);
    _key = TextEditingController(text: s.apiKey);
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    super.dispose();
  }

  void _toast(String t) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(t)));
  }

  Future<void> _saveServer() async {
    final app = context.read<AppState>();
    final err = await app.setManualUrl(_url.text);
    await app.setApiKey(_key.text);
    if (!mounted) return;
    _toast(err ?? 'Đã lưu. Đang kiểm tra máy chủ…');
  }

  Future<void> _googleSignIn() async {
    final app = context.read<AppState>();
    setState(() => _signing = true);
    final err = await app.googleSignIn();
    if (!mounted) return;
    setState(() => _signing = false);
    _toast(err ?? 'Đã đăng nhập Google.');
  }

  Future<void> _deleteMyData() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa dữ liệu của tôi?'),
        content: const Text(
            'Mọi hội thoại trên điện thoại sẽ bị xóa, và các hội thoại đã lưu trên máy chủ sẽ bị yêu cầu xóa. '
            'Không thể hoàn tác.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xóa hết')),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    final app = context.read<AppState>();
    setState(() => _deleting = true);
    final ids = await app.db.savedConversationIds();
    var failed = 0;
    for (final id in ids) {
      try {
        await app.forgetOnServer(id);
      } catch (_) {
        failed++;
      }
    }
    if (!mounted) return;
    setState(() => _deleting = false);

    if (failed > 0) {
      // Một số hội thoại chưa xóa được trên máy chủ (vd. máy chủ đang tắt)
      final localOnly = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Chưa xóa hết trên máy chủ'),
          content: Text('$failed hội thoại chưa xóa được trên máy chủ (máy chủ tắt hoặc lỗi mạng). '
              'Dữ liệu trên điện thoại CHƯA bị xóa. Bạn có thể bật máy chủ rồi thử lại, '
              'hoặc chỉ xóa trên điện thoại (khi đó sẽ không còn cách yêu cầu xóa các hội thoại đó từ app).'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Để thử lại sau')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true), child: const Text('Chỉ xóa trên máy')),
          ],
        ),
      );
      if (localOnly != true || !mounted) return;
    }
    await app.db.deleteAll();
    if (!mounted) return;
    _toast('Đã xóa dữ liệu của bạn.');
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = app.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt')),
      body: Column(
        children: [
          const ServerStatusBar(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (AuthService.supported) ...[
                  const _Header('Tài khoản'),
                  if (s.googleOn && app.auth.signedIn)
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.account_circle),
                        title: Text(app.auth.email ?? ''),
                        subtitle: Text(app.accountInfo ?? 'Đã đăng nhập Google'),
                        trailing: TextButton(
                          onPressed: app.googleSignOut,
                          child: const Text('Đăng xuất'),
                        ),
                      ),
                    )
                  else ...[
                    FilledButton.tonalIcon(
                      onPressed: _signing ? null : _googleSignIn,
                      icon: _signing
                          ? const SizedBox(
                              width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.login),
                      label: const Text('Đăng nhập bằng Google'),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      app.googleClientId == null
                          ? 'Máy chủ hiện chưa báo hỗ trợ đăng nhập Google (máy chủ tắt hoặc bản cũ). Vẫn dùng được khóa API bên dưới.'
                          : 'Đăng nhập xong không cần nhập khóa API, máy chủ tự nhận ra tài khoản của bạn.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ],
                const _Header('Máy chủ'),
                TextField(
                  controller: _url,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'Địa chỉ máy chủ (tùy chọn)',
                    hintText: 'https://xxxx.trycloudflare.com',
                    helperText: 'Để trống = tự đọc từ server.json. Nếu nhập, sẽ được ưu tiên.',
                    helperMaxLines: 2,
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _key,
                  obscureText: !_showKey,
                  autocorrect: false,
                  enableSuggestions: false,
                  decoration: InputDecoration(
                    labelText: 'Khóa API (nếu không đăng nhập Google)',
                    helperText: 'Nhập một lần, lưu mã hóa trong điện thoại.',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(_showKey ? Icons.visibility_off : Icons.visibility),
                      onPressed: () => setState(() => _showKey = !_showKey),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _saveServer,
                  icon: const Icon(Icons.save),
                  label: const Text('Lưu & kiểm tra kết nối'),
                ),
                const SizedBox(height: 8),
                const _Header('Trả lời'),
                Text('Temperature: ${s.temperature.toStringAsFixed(2)}'),
                Slider(
                  min: 0.1,
                  max: 1.5,
                  divisions: 14,
                  value: s.temperature.clamp(0.1, 1.5),
                  label: s.temperature.toStringAsFixed(1),
                  onChanged: (v) => app.setTemperature(double.parse(v.toStringAsFixed(2))),
                ),
                Text('Độ dài tối đa: ${s.maxTokens} token'),
                Slider(
                  min: 16,
                  max: 1000,
                  divisions: 123,
                  value: s.maxTokens.clamp(16, 1000).toDouble(),
                  label: '${s.maxTokens}',
                  onChanged: (v) => app.setMaxTokens(v.round()),
                ),
                const _Header('Quyền riêng tư'),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Cho phép lưu hội thoại để cải thiện EON'),
                  subtitle: const Text(
                      'Tắt: hội thoại chỉ nằm trong điện thoại. Bật: gửi kèm save=true, '
                      'thông tin cá nhân được ẩn trên máy chủ.'),
                  value: s.saveAllowed,
                  onChanged: app.setSaveAllowed,
                ),
                const SizedBox(height: 4),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                      foregroundColor: Theme.of(context).colorScheme.error),
                  onPressed: _deleting ? null : _deleteMyData,
                  icon: _deleting
                      ? const SizedBox(
                          width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.delete_forever),
                  label: const Text('Xóa dữ liệu của tôi'),
                ),
                const _Header('Giao diện'),
                SegmentedButton<ThemeMode>(
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('Theo máy'), icon: Icon(Icons.brightness_auto)),
                    ButtonSegment(value: ThemeMode.light, label: Text('Sáng'), icon: Icon(Icons.light_mode)),
                    ButtonSegment(value: ThemeMode.dark, label: Text('Tối'), icon: Icon(Icons.dark_mode)),
                  ],
                  selected: {s.themeMode},
                  onSelectionChanged: (v) => app.setThemeMode(v.first),
                ),
                const SizedBox(height: 24),
                if (app.adapter != null)
                  Text('Mô hình: ${app.adapter}',
                      style: Theme.of(context).textTheme.bodySmall),
                Text('EON GPT 1.0', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 8),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleSmall
                ?.copyWith(color: Theme.of(context).colorScheme.primary)),
      );
}
