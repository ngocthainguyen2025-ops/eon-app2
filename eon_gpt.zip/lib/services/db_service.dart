import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/conversation.dart';
import '../models/message.dart';

/// SQLite cục bộ: hội thoại + tin nhắn (kèm conversation_id và message_index).
class DbService {
  Database? _db;

  Future<Database> get _database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'eon_gpt.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (d, v) async {
        await d.execute('''
          CREATE TABLE conversations(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            saved INTEGER NOT NULL DEFAULT 0
          )''');
        await d.execute('''
          CREATE TABLE messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            server_index INTEGER,
            saved INTEGER NOT NULL DEFAULT 0,
            rating TEXT,
            interrupted INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
          )''');
        await d.execute('CREATE INDEX idx_msg_conv ON messages(conversation_id, id)');
      },
    );
  }

  // ---------- Hội thoại ----------
  Future<List<Conversation>> listConversations({String query = ''}) async {
    final d = await _database;
    final q = query.trim();
    List<Map<String, Object?>> rows;
    if (q.isEmpty) {
      rows = await d.query('conversations', orderBy: 'updated_at DESC');
    } else {
      final like = '%$q%';
      rows = await d.rawQuery('''
        SELECT DISTINCT c.* FROM conversations c
        LEFT JOIN messages m ON m.conversation_id = c.id
        WHERE c.title LIKE ? OR m.content LIKE ?
        ORDER BY c.updated_at DESC''', [like, like]);
    }
    return rows.map(Conversation.fromMap).toList();
  }

  Future<Conversation?> getConversation(String id) async {
    final d = await _database;
    final rows = await d.query('conversations', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : Conversation.fromMap(rows.first);
  }

  Future<void> insertConversation(Conversation c) async {
    final d = await _database;
    await d.insert('conversations', c.toMap());
  }

  Future<void> renameConversation(String id, String title) async {
    final d = await _database;
    await d.update('conversations', {'title': title}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> touchConversation(String id) async {
    final d = await _database;
    await d.update('conversations', {'updated_at': DateTime.now().millisecondsSinceEpoch},
        where: 'id = ?', whereArgs: [id]);
  }

  Future<void> markConversationSaved(String id) async {
    final d = await _database;
    await d.update('conversations', {'saved': 1}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteConversation(String id) async {
    final d = await _database;
    await d.delete('messages', where: 'conversation_id = ?', whereArgs: [id]);
    await d.delete('conversations', where: 'id = ?', whereArgs: [id]);
  }

  /// Danh sách id các hội thoại đã được lưu trên máy chủ (để gọi /forget).
  Future<List<String>> savedConversationIds() async {
    final d = await _database;
    final rows = await d.query('conversations', columns: ['id'], where: 'saved = 1');
    return rows.map((r) => r['id'] as String).toList();
  }

  Future<void> deleteAll() async {
    final d = await _database;
    await d.delete('messages');
    await d.delete('conversations');
  }

  // ---------- Tin nhắn ----------
  Future<List<Message>> listMessages(String conversationId) async {
    final d = await _database;
    final rows = await d.query('messages',
        where: 'conversation_id = ?', whereArgs: [conversationId], orderBy: 'id ASC');
    return rows.map(Message.fromMap).toList();
  }

  Future<int> insertMessage(Message m) async {
    final d = await _database;
    return d.insert('messages', m.toMap());
  }

  Future<void> deleteMessage(int id) async {
    final d = await _database;
    await d.delete('messages', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> updateRating(int id, String rating) async {
    final d = await _database;
    await d.update('messages', {'rating': rating}, where: 'id = ?', whereArgs: [id]);
  }
}
