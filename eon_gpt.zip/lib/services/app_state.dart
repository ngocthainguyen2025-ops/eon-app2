import 'dart:async';

import 'package:flutter/material.dart';

import '../models/app_settings.dart';
import 'api_service.dart';
import 'auth_service.dart';
import 'db_service.dart';
import 'discovery_service.dart';
import 'settings_store.dart';

enum ServerStatus { off, connecting, ready }

/// Trạng thái toàn app: cài đặt + trạng thái máy chủ.
class AppState extends ChangeNotifier with WidgetsBindingObserver {
  AppState({
    required this.store,
    required this.discovery,
    required this.api,
    required this.db,
  });

  final SettingsStore store;
  final DiscoveryService discovery;
  final ApiService api;
  final DbService db;

  final AuthService auth = AuthService();
  String? googleClientId; // máy chủ báo qua /health; null = máy chủ chưa bật đăng nhập Google
  String? accountInfo; // vd. "Còn 95/100 lượt hôm nay"

  AppSettings settings = AppSettings();
  bool loaded = false;

  ServerStatus status = ServerStatus.connecting;
  String statusDetail = '';
  String? baseUrl; // địa chỉ đang dùng (đã kiểm tra /health)
  String? adapter;
  int waiting = 0;

  Timer? _timer;
  bool _refreshing = false;
  bool _disposed = false;

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> init() async {
    settings = await store.load();
    loaded = true;
    _notify();
    WidgetsBinding.instance.addObserver(this);
    _startTimer();
    refreshServer();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // ---------- Kiểm tra định kỳ khi app mở ----------
  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => refreshServer(silent: true));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _startTimer();
      refreshServer();
    } else if (state == AppLifecycleState.paused) {
      _timer?.cancel();
    }
  }

  // ---------- Tìm máy chủ ----------
  /// Đọc server.json (hoặc dùng địa chỉ nhập tay) rồi gọi /health.
  /// [silent]: kiểm tra định kỳ, không nháy "Đang kết nối" nếu đang Sẵn sàng.
  Future<void> refreshServer({bool silent = false}) async {
    if (_refreshing) return;
    _refreshing = true;
    try {
      if (!silent || status != ServerStatus.ready) {
        status = ServerStatus.connecting;
        statusDetail = '';
        _notify();
      }

      String? url;
      if (settings.manualUrl.isNotEmpty) {
        url = settings.manualUrl; // ưu tiên địa chỉ nhập tay
      } else {
        final info = await discovery.fetch();
        url = info?.url;
        if (url == null) {
          baseUrl = null;
          status = ServerStatus.off;
          statusDetail = 'Chưa có địa chỉ máy chủ (server.json trống hoặc không đọc được).';
          return;
        }
      }

      final h = await api.health(url);
      if (h == null) {
        baseUrl = null;
        status = ServerStatus.off;
        statusDetail = 'Không gọi được /health.';
      } else {
        baseUrl = url;
        adapter = h.adapter;
        waiting = h.waiting;
        googleClientId = h.googleClientId;
        auth.configure(googleClientId);
        if (settings.googleOn && !auth.signedIn) {
          auth.trySilent().then((_) => _notify());
        }
        if (h.modelReady) {
          status = ServerStatus.ready;
          statusDetail = h.waiting > 0 ? 'Đang chờ: ${h.waiting}' : '';
        } else {
          status = ServerStatus.connecting;
          statusDetail = 'Máy chủ đang nạp mô hình…';
        }
      }
    } finally {
      _refreshing = false;
      _notify();
    }
  }

  /// Đảm bảo có địa chỉ + thông tin đăng nhập trước khi gọi API. Ném ApiException nếu thiếu.
  /// key = 'google:<ID token>' (đăng nhập Google) hoặc khóa API.
  Future<({String url, String key})> requireServer() async {
    if (baseUrl == null || status == ServerStatus.off) await refreshServer();
    final url = baseUrl;
    if (url == null || status == ServerStatus.off) {
      throw const ApiException(0, 'Máy chủ đang tắt. Hãy bật máy chủ trên Kaggle/Colab rồi bấm "Thử lại".');
    }
    String cred = '';
    if (settings.googleOn && AuthService.supported) {
      auth.configure(googleClientId);
      final t = await auth.idToken();
      if (t != null) cred = 'google:$t';
    }
    if (cred.isEmpty) cred = settings.apiKey;
    if (cred.isEmpty) {
      throw const ApiException(
          401, 'Chưa đăng nhập. Hãy vào Cài đặt: đăng nhập Google hoặc nhập khóa API.');
    }
    return (url: url, key: cred);
  }

  // ---------- Đăng nhập Google ----------
  /// Trả về chuỗi lỗi, hoặc null nếu thành công.
  Future<String?> googleSignIn() async {
    if (!AuthService.supported) return 'Đăng nhập Google chỉ có trên Android.';
    if (googleClientId == null) await refreshServer();
    if (googleClientId == null) {
      return 'Máy chủ chưa bật đăng nhập Google (hoặc đang tắt). Hãy bật máy chủ bản mới rồi thử lại.';
    }
    auth.configure(googleClientId);
    final err = await auth.signIn();
    if (err != null) return err;
    settings.googleOn = true;
    await store.saveGoogleOn(true);
    _notify();
    return checkAccount();
  }

  /// Hỏi máy chủ xem tài khoản có được phép không + còn bao nhiêu lượt. Trả lỗi hoặc null.
  Future<String?> checkAccount() async {
    try {
      final s = await requireServer();
      final j = await api.me(baseUrl: s.url, cred: s.key);
      final q = j['quota'];
      if (q is Map && q['limit'] is num && q['used'] is num) {
        final left = (q['limit'] as num).toInt() - (q['used'] as num).toInt();
        accountInfo = 'Còn $left/${(q['limit'] as num).toInt()} lượt hôm nay';
      } else {
        accountInfo = 'Không giới hạn lượt';
      }
      _notify();
      return null;
    } on ApiException catch (e) {
      if (e.status == 401 || e.status == 403) await googleSignOut();
      return e.message;
    }
  }

  Future<void> googleSignOut() async {
    await auth.signOut();
    settings.googleOn = false;
    accountInfo = null;
    await store.saveGoogleOn(false);
    _notify();
  }

  // ---------- Cài đặt ----------
  /// Trả về chuỗi lỗi nếu địa chỉ không hợp lệ, null nếu ổn. Rỗng = xóa địa chỉ tay.
  Future<String?> setManualUrl(String raw) async {
    var s = raw.trim();
    if (s.isNotEmpty) {
      if (s.startsWith('http://')) return 'Chỉ dùng địa chỉ HTTPS (https://...).';
      if (!s.startsWith('https://')) s = 'https://$s';
      while (s.endsWith('/')) {
        s = s.substring(0, s.length - 1);
      }
      final u = Uri.tryParse(s);
      if (u == null || u.host.isEmpty) return 'Địa chỉ không hợp lệ.';
    }
    settings.manualUrl = s;
    await store.saveManualUrl(s);
    _notify();
    refreshServer();
    return null;
  }

  Future<void> setApiKey(String key) async {
    settings.apiKey = key.trim();
    await store.saveApiKey(settings.apiKey);
    _notify();
  }

  Future<void> setTemperature(double v) async {
    settings.temperature = v;
    _notify();
    await store.saveTemperature(v);
  }

  Future<void> setMaxTokens(int v) async {
    settings.maxTokens = v;
    _notify();
    await store.saveMaxTokens(v);
  }

  Future<void> setSaveAllowed(bool v) async {
    settings.saveAllowed = v;
    _notify();
    await store.saveSaveAllowed(v);
  }

  Future<void> setThemeMode(ThemeMode m) async {
    settings.themeMode = m;
    _notify();
    await store.saveThemeMode(m);
  }

  Future<void> completePrivacy({required bool allowSave}) async {
    settings.saveAllowed = allowSave;
    settings.privacySeen = true;
    await store.saveSaveAllowed(allowSave);
    await store.savePrivacySeen(true);
    _notify();
  }

  // ---------- Xóa dữ liệu ----------
  /// Gọi /forget cho một hội thoại. Ném ApiException nếu lỗi.
  Future<void> forgetOnServer(String conversationId) async {
    final s = await requireServer();
    await api.forget(baseUrl: s.url, apiKey: s.key, conversationId: conversationId);
  }
}
