import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

/// Đăng nhập Google (chỉ Android). Lấy "ID token" gửi cho máy chủ; máy chủ tự kiểm tra
/// và nhận ra tài khoản, nên không cần nhập khóa API.
/// ID token sống ~1 giờ; hàm [idToken] tự làm mới khi sắp hết hạn.
class AuthService {
  GoogleSignIn? _gsi;
  String? _clientId;
  String? email;
  String? displayName;
  String? _idToken;
  DateTime _exp = DateTime.fromMillisecondsSinceEpoch(0);

  static bool get supported => !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  bool get signedIn => email != null;

  /// [clientId] = Web client ID do máy chủ báo qua /health.
  void configure(String? clientId) {
    if (!supported || clientId == null || clientId.isEmpty) return;
    if (_gsi != null && _clientId == clientId) return;
    _clientId = clientId;
    _gsi = GoogleSignIn(scopes: const ['email'], serverClientId: clientId);
    _idToken = null;
  }

  void _apply(GoogleSignInAccount? a) {
    email = a?.email;
    displayName = a?.displayName;
    if (a == null) _idToken = null;
  }

  /// Đăng nhập âm thầm (nếu trước đó đã đăng nhập).
  Future<bool> trySilent() async {
    final g = _gsi;
    if (g == null) return false;
    try {
      final a = await g.signInSilently();
      _apply(a);
      return a != null;
    } catch (_) {
      return false;
    }
  }

  /// Hiện cửa sổ chọn tài khoản Google. Trả về chuỗi lỗi, hoặc null nếu thành công.
  Future<String?> signIn() async {
    final g = _gsi;
    if (g == null) return 'Chưa có thông tin đăng nhập Google từ máy chủ.';
    try {
      final a = await g.signIn();
      if (a == null) return 'Bạn đã hủy đăng nhập.';
      _apply(a);
      _idToken = null;
      return null;
    } catch (e) {
      final s = e.toString();
      if (s.contains('ApiException: 10') || s.contains('DEVELOPER_ERROR')) {
        return 'Lỗi cấu hình Google (mã 10): tên gói hoặc SHA-1 của app chưa khớp với OAuth Client kiểu Android trong Google Cloud.';
      }
      if (s.contains('12500')) {
        return 'Đăng nhập thất bại (12500): kiểm tra "Màn hình xin phép OAuth" đã điền email hỗ trợ chưa.';
      }
      if (s.contains('network_error') || s.contains('7:')) {
        return 'Không có mạng để đăng nhập Google.';
      }
      return 'Đăng nhập Google thất bại.';
    }
  }

  Future<void> signOut() async {
    try {
      await _gsi?.signOut();
    } catch (_) {}
    _apply(null);
  }

  /// ID token còn hạn (làm mới nếu còn dưới 5 phút). null nếu chưa đăng nhập / lỗi.
  Future<String?> idToken() async {
    final g = _gsi;
    if (g == null) return null;
    if (_idToken != null && _exp.isAfter(DateTime.now().add(const Duration(minutes: 5)))) {
      return _idToken;
    }
    try {
      GoogleSignInAccount? a = await g.signInSilently(reAuthenticate: true);
      a ??= g.currentUser;
      if (a == null) {
        _apply(null);
        return null;
      }
      _apply(a);
      final t = (await a.authentication).idToken;
      if (t == null || t.isEmpty) return null;
      _idToken = t;
      _exp = _expOf(t);
      return t;
    } catch (_) {
      return null;
    }
  }

  static DateTime _expOf(String jwt) {
    try {
      final parts = jwt.split('.');
      final payload = utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
      final j = jsonDecode(payload);
      final e = (j is Map && j['exp'] is num) ? (j['exp'] as num).toInt() : 0;
      if (e > 0) return DateTime.fromMillisecondsSinceEpoch(e * 1000);
    } catch (_) {}
    return DateTime.now().add(const Duration(minutes: 30));
  }
}
