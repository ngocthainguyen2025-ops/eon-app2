import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/chat_event.dart';

/// Lỗi gọi API. status = 0 nghĩa là lỗi mạng (không tới được máy chủ).
class ApiException implements Exception {
  final int status;
  final String message;
  const ApiException(this.status, this.message);
  bool get isNetwork => status == 0;
  @override
  String toString() => message; // KHÔNG đưa khóa/nội dung hội thoại vào đây
}

/// Dùng để dừng một lần gọi /chat đang chạy.
class CancelToken {
  bool cancelled = false;
  http.Client? client;
  void cancel() {
    cancelled = true;
    client?.close(); // đóng kết nối -> luồng SSE dừng ngay
  }
}

/// Gọi máy chủ EON. Không giữ trạng thái; địa chỉ và khóa truyền vào mỗi lần gọi.
/// Không in log bất kỳ nội dung hội thoại hay khóa nào.
class ApiService {
  static const _retryDelays = [Duration(seconds: 2), Duration(seconds: 4), Duration(seconds: 8)];

  /// Thông báo tiếng Việt theo mã lỗi.
  static String messageFor(int status) {
    switch (status) {
      case 401:
        return 'Chưa đăng nhập hoặc sai khóa API. Hãy đăng nhập Google / kiểm tra khóa trong Cài đặt.';
      case 403:
        return 'Tài khoản này không được dùng máy chủ (hoặc đã hết lượt hôm nay).';
      case 400:
        return 'Dữ liệu gửi đi không hợp lệ (có thể tin nhắn quá dài).';
      case 429:
        return 'Bạn gửi quá nhanh (tối đa 20 lần/phút). Đợi một lát rồi thử lại.';
      case 503:
        return 'Máy chủ đang bận. Hãy thử lại sau ít phút.';
      case 404:
        return 'Không tìm thấy dữ liệu trên máy chủ (404).';
      default:
        return 'Máy chủ báo lỗi (mã $status).';
    }
  }

  /// [cred] là khóa API, hoặc 'google:<ID token>' khi đăng nhập Google.
  static Map<String, String> _auth(String cred) => cred.startsWith('google:')
      ? {'Authorization': 'Bearer ${cred.substring(7)}'}
      : {'X-API-Key': cred};

  static const _networkMsg =
      'Không kết nối được tới máy chủ. Có thể máy chủ đã tắt hoặc mạng yếu.';

  /// GET /health (không cần khóa). Trả null nếu không gọi được / chưa ok.
  Future<HealthInfo?> health(String baseUrl) async {
    try {
      final r = await http
          .get(Uri.parse('$baseUrl/health'))
          .timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (j is! Map || j['ok'] != true) return null;
      return HealthInfo(
        modelReady: j['model_ready'] == true,
        adapter: j['adapter']?.toString(),
        waiting: (j['waiting'] is num) ? (j['waiting'] as num).toInt() : 0,
        googleClientId: (j['google_client_id'] is String && (j['google_client_id'] as String).isNotEmpty)
            ? j['google_client_id'] as String
            : null,
      );
    } catch (_) {
      return null;
    }
  }

  /// POST /chat với stream=true. Phát ra các [ChatEvent].
  /// - 429/503: tự thử lại chờ tăng dần (2s, 4s, 8s - tối đa 3 lần).
  /// - Đứt kết nối giữa chừng: ném ApiException(status 0) -> bên gọi giữ phần đã nhận.
  /// - Người dùng bấm Dừng ([token].cancel()): luồng kết thúc êm, không ném lỗi.
  Stream<ChatEvent> chatStream({
    required String baseUrl,
    required String apiKey,
    required List<Map<String, String>> messages,
    required double temperature,
    required int maxTokens,
    required bool save,
    required String conversationId,
    required CancelToken token,
    void Function(int attempt)? onRetry,
  }) async* {
    final body = jsonEncode({
      'messages': messages,
      'temperature': temperature,
      'max_new_tokens': maxTokens,
      'stream': true,
      'save': save,
      'conversation_id': conversationId,
    });

    http.StreamedResponse? resp;
    for (var attempt = 0;; attempt++) {
      if (token.cancelled) return;
      final client = http.Client();
      token.client = client;
      http.StreamedResponse r;
      try {
        final req = http.Request('POST', Uri.parse('$baseUrl/chat'))
          ..headers.addAll({
            'Content-Type': 'application/json; charset=utf-8',
            'Accept': 'text/event-stream',
          })
          ..headers.addAll(_auth(apiKey))
          ..body = body;
        r = await client.send(req).timeout(const Duration(seconds: 60));
      } catch (_) {
        client.close();
        if (token.cancelled) return;
        throw const ApiException(0, _networkMsg);
      }

      final code = r.statusCode;
      if ((code == 429 || code == 503) && attempt < _retryDelays.length) {
        try {
          await r.stream.drain<void>();
        } catch (_) {}
        client.close();
        onRetry?.call(attempt + 1);
        await Future<void>.delayed(_retryDelays[attempt]);
        continue;
      }
      if (code != 200) {
        String text = '';
        try {
          text = await r.stream.bytesToString();
        } catch (_) {}
        client.close();
        throw ApiException(code, _withDetail(code, text));
      }
      resp = r;
      break; // 200 OK: đọc luồng
    }

    try {
      final lines = resp!.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .timeout(const Duration(seconds: 120)); // 120s không có dữ liệu = coi như đứt
      await for (final line in lines) {
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload.isEmpty || payload == '[DONE]') continue;
        Object? j;
        try {
          j = jsonDecode(payload);
        } catch (_) {
          continue; // bỏ qua dòng hỏng
        }
        if (j is! Map) continue;
        if (j['error'] != null) {
          throw ApiException(500, 'Máy chủ báo lỗi: ${j['error']}');
        }
        if (j['delta'] is String) {
          yield ChatEvent.delta(j['delta'] as String);
        }
        if (j['done'] == true) {
          yield ChatEvent.done(
            reply: j['reply']?.toString(),
            messageIndex: (j['message_index'] is num) ? (j['message_index'] as num).toInt() : null,
          );
          return;
        }
      }
      // Luồng kết thúc mà chưa có "done" => bị đứt giữa chừng
      if (!token.cancelled) throw const ApiException(0, 'Kết nối bị ngắt giữa chừng.');
    } on ApiException {
      rethrow;
    } catch (_) {
      if (token.cancelled) return;
      throw const ApiException(0, 'Kết nối bị ngắt giữa chừng.');
    } finally {
      token.client?.close();
    }
  }

  /// GET /me: thông tin tài khoản + hạn mức hôm nay. Ném ApiException nếu lỗi.
  Future<Map<String, dynamic>> me({required String baseUrl, required String cred}) async {
    http.Response r;
    try {
      r = await http
          .get(Uri.parse('$baseUrl/me'), headers: _auth(cred))
          .timeout(const Duration(seconds: 15));
    } catch (_) {
      throw const ApiException(0, _networkMsg);
    }
    if (r.statusCode != 200) {
      throw ApiException(r.statusCode, _withDetail(r.statusCode, utf8.decode(r.bodyBytes, allowMalformed: true)));
    }
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    return j is Map<String, dynamic> ? j : <String, dynamic>{};
  }

  /// POST /feedback
  Future<void> feedback({
    required String baseUrl,
    required String apiKey,
    required String conversationId,
    required int messageIndex,
    String? rating,
    String? correctedText,
  }) async {
    await _postJson(baseUrl, apiKey, '/feedback', {
      'conversation_id': conversationId,
      'message_index': messageIndex,
      if (rating != null) 'rating': rating,
      if (correctedText != null) 'corrected_text': correctedText,
    }, notFoundMsg: 'Máy chủ chưa lưu hội thoại này (cần bật "Cho phép lưu hội thoại" trước khi trò chuyện).');
  }

  /// POST /forget
  Future<void> forget({
    required String baseUrl,
    required String apiKey,
    required String conversationId,
  }) async {
    await _postJson(baseUrl, apiKey, '/forget', {'conversation_id': conversationId});
  }

  Future<void> _postJson(String baseUrl, String apiKey, String path, Map<String, Object?> body,
      {String? notFoundMsg}) async {
    http.Response r;
    try {
      r = await http
          .post(
            Uri.parse('$baseUrl$path'),
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              ..._auth(apiKey),
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      throw const ApiException(0, _networkMsg);
    }
    if (r.statusCode == 200) return;
    if (r.statusCode == 404 && notFoundMsg != null) {
      throw ApiException(404, notFoundMsg);
    }
    throw ApiException(r.statusCode, _withDetail(r.statusCode, utf8.decode(r.bodyBytes, allowMalformed: true)));
  }

  /// Ghép thông báo chuẩn với chi tiết (detail) do máy chủ trả, nếu có.
  String _withDetail(int code, String body) {
    final base = messageFor(code);
    try {
      final j = jsonDecode(body);
      if (j is Map && j['detail'] is String && code != 401) {
        return '$base (${j['detail']})';
      }
    } catch (_) {}
    return base;
  }
}
