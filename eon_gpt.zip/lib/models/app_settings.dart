import 'package:flutter/material.dart';

/// Cài đặt của người dùng. Khóa API được lưu riêng bằng flutter_secure_storage.
class AppSettings {
  /// Địa chỉ nhập tay (ưu tiên hơn server.json). Rỗng = tự tìm.
  String manualUrl;
  String apiKey;

  /// Đang dùng đăng nhập Google (thay cho khóa API)
  bool googleOn;
  double temperature;
  int maxTokens;

  /// "Cho phép lưu hội thoại để cải thiện EON" — MẶC ĐỊNH TẮT
  bool saveAllowed;
  ThemeMode themeMode;
  bool privacySeen;

  AppSettings({
    this.manualUrl = '',
    this.apiKey = '',
    this.googleOn = false,
    this.temperature = 0.7,
    this.maxTokens = 512,
    this.saveAllowed = false,
    this.themeMode = ThemeMode.system,
    this.privacySeen = false,
  });
}
