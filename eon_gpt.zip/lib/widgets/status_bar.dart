import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../screens/settings_screen.dart';
import '../services/app_state.dart';

/// Thanh trạng thái máy chủ: Máy chủ đang tắt / Đang kết nối / Sẵn sàng.
class ServerStatusBar extends StatelessWidget {
  const ServerStatusBar({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    late final Color color;
    late final String text;
    switch (app.status) {
      case ServerStatus.ready:
        color = Colors.green;
        text = 'Sẵn sàng';
      case ServerStatus.connecting:
        color = Colors.orange;
        text = 'Đang kết nối';
      case ServerStatus.off:
        color = Colors.red;
        text = 'Máy chủ đang tắt';
    }
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (app.statusDetail.isNotEmpty)
                    Text(app.statusDetail,
                        style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                ],
              ),
            ),
            if (app.status == ServerStatus.connecting)
              const SizedBox(
                  width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
            else ...[
              TextButton(
                onPressed: () => app.refreshServer(),
                child: const Text('Thử lại'),
              ),
              if (app.status == ServerStatus.off)
                TextButton(
                  onPressed: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
                  child: const Text('Nhập địa chỉ'),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
