import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import 'package:flutter_highlight/themes/github.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:markdown/markdown.dart' as md;

/// Các ngôn ngữ đã biết chắc là có trong thư viện tô màu (tránh lỗi ngôn ngữ lạ).
const _known = {
  'dart', 'python', 'javascript', 'typescript', 'java', 'kotlin', 'cpp', 'c', 'cs',
  'go', 'rust', 'php', 'ruby', 'swift', 'bash', 'shell', 'sql', 'json', 'yaml',
  'xml', 'css', 'scss', 'markdown', 'dockerfile', 'lua', 'r', 'powershell', 'ini', 'diff',
};

const _alias = {
  'js': 'javascript', 'jsx': 'javascript', 'ts': 'typescript', 'tsx': 'typescript',
  'py': 'python', 'python3': 'python', 'sh': 'bash', 'zsh': 'bash', 'html': 'xml',
  'kt': 'kotlin', 'c++': 'cpp', 'csharp': 'cs', 'c#': 'cs', 'yml': 'yaml',
  'golang': 'go', 'rs': 'rust', 'md': 'markdown', 'ps1': 'powershell', 'toml': 'ini',
};

String? _normalize(String lang) {
  var l = lang.trim().toLowerCase();
  l = _alias[l] ?? l;
  return _known.contains(l) ? l : null;
}

/// Khối code: tô màu + nút "Sao chép".
class CodeBlock extends StatelessWidget {
  final String code;
  final String language;
  const CodeBlock({super.key, required this.code, required this.language});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final theme = dark ? atomOneDarkTheme : githubTheme;
    final bg = theme['root']?.backgroundColor ?? (dark ? const Color(0xff282c34) : const Color(0xfff6f8fa));
    final fg = theme['root']?.color ?? (dark ? Colors.white : Colors.black87);
    final lang = _normalize(language);
    const mono = TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.4);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            color: fg.withAlpha(25),
            padding: const EdgeInsets.only(left: 12, right: 4),
            height: 36,
            child: Row(
              children: [
                Expanded(
                  child: Text(language.isEmpty ? 'code' : language,
                      style: TextStyle(color: fg.withAlpha(180), fontSize: 12)),
                ),
                TextButton.icon(
                  style: TextButton.styleFrom(
                      foregroundColor: fg, visualDensity: VisualDensity.compact),
                  icon: const Icon(Icons.copy, size: 16),
                  label: const Text('Sao chép'),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: code));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context)
                        ..hideCurrentSnackBar()
                        ..showSnackBar(const SnackBar(
                            content: Text('Đã sao chép code'), duration: Duration(seconds: 1)));
                    }
                  },
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: lang == null
                ? Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(code, style: mono.copyWith(color: fg)),
                  )
                : HighlightView(
                    code,
                    language: lang,
                    theme: theme,
                    padding: const EdgeInsets.all(12),
                    textStyle: mono,
                  ),
          ),
        ],
      ),
    );
  }
}

/// Cắm vào flutter_markdown: thay khối ``` bằng [CodeBlock].
class CodeBlockBuilder extends MarkdownElementBuilder {
  @override
  Widget? visitElementAfterWithContext(BuildContext context, md.Element element,
      TextStyle? preferredStyle, TextStyle? parentStyle) {
    var lang = '';
    final kids = element.children;
    if (kids != null && kids.isNotEmpty) {
      final first = kids.first;
      if (first is md.Element) {
        final cls = first.attributes['class'];
        if (cls != null && cls.startsWith('language-')) {
          lang = cls.substring('language-'.length);
        }
      }
    }
    var code = element.textContent;
    if (code.endsWith('\n')) code = code.substring(0, code.length - 1);
    return CodeBlock(code: code, language: lang);
  }
}
