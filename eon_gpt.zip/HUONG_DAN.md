# EON GPT (Flutter, Android) — Hướng dẫn nhanh

App chỉ là giao diện: tự đọc địa chỉ máy chủ từ `server.json` trên Hugging Face rồi gọi API trên Kaggle.

## 1. Đẩy mã lên GitHub từ điện thoại (làm 1 lần)
1. Vào github.com (Chrome → menu ⋮ → **Trang web cho máy tính**), tạo repo mới, ví dụ `eon-app` (Public hoặc Private đều được).
2. Trong repo: **Add file → Upload files** → chọn file **`eon_gpt.zip`** (đừng giải nén) → **Commit changes**.
3. **Add file → Create new file**, ở ô tên gõ đúng: `.github/workflows/build.yml` (gõ dấu `/` là GitHub tự tạo thư mục). Dán toàn bộ nội dung file `build.yml` vào → **Commit changes**.
   → Lần đẩy này tự kích hoạt build (workflow sẽ tự giải nén `eon_gpt.zip`).
4. Muốn build lại: tab **Actions → Build EON GPT APK → Run workflow**.

## 2. Tải APK (build mất ~5–8 phút)
- Cách dễ nhất: tab **Releases** (bên phải trang repo) → bản **latest** → bấm `app-release.apk` để tải.
- Hoặc: tab **Actions** → bấm lần chạy mới nhất (dấu ✓ xanh) → mục **Artifacts** → `EON-GPT-apk` (file zip, giải nén ra `app-release.apk`).

## 3. Cài
Mở file APK vừa tải → nếu máy hỏi, cho phép "Cài ứng dụng từ nguồn này" cho trình duyệt/Files → Cài đặt. (APK ký khóa debug, dùng để cài thử.)

## 4. Dùng lần đầu
1. Đọc màn hình quyền riêng tư (công tắc lưu hội thoại mặc định TẮT) → Tiếp tục.
2. Bật máy chủ trên Kaggle (notebook `chat_eon_api.ipynb`). App tự đọc `server.json`; thanh trên cùng báo **Sẵn sàng**.
3. ⚙ Cài đặt → dán **Khóa API** → "Lưu & kiểm tra kết nối". (Có thể nhập địa chỉ tay, ưu tiên hơn server.json.)
4. Bấm **+ Mới** để chat.

## 4b. Đăng nhập Google
Xem `HUONG_DAN_GOOGLE.md` (tạo Client ID 1 lần, thêm secret `GOOGLE_CLIENT_ID` cho máy chủ). Trong zip có `signing/debug.keystore`: khóa ký cố định để SHA-1 không đổi giữa các lần build.

## 5. Cấu trúc mã
```
lib/
  main.dart                      khởi động, theme, chọn màn hình đầu
  models/                        message, conversation, app_settings, chat_event
  services/
    auth_service.dart            đăng nhập Google (ID token)
    api_service.dart             /health, /chat (SSE), /feedback, /forget, thử lại 429/503
    discovery_service.dart       đọc server.json
    settings_store.dart          SharedPreferences + flutter_secure_storage (khóa API)
    db_service.dart              SQLite (sqflite)
    app_state.dart               cài đặt + trạng thái máy chủ (kiểm tra mỗi 30s)
    chat_controller.dart         luồng chat, lưu tin, phản hồi
  screens/                       privacy, conversations, chat, settings
  widgets/                       message_bubble, code_block, status_bar
.github/workflows/build.yml      build APK
```

## 6. Ghi chú
- Gửi tối đa 12 lượt gần nhất (24 tin), mỗi tin cắt ở 6000 ký tự; không gửi role `system`.
- `save=true` chỉ gửi khi công tắc bật. 👍/👎/Sửa chỉ gửi được cho câu trả lời tạo lúc công tắc đang bật (nếu không máy chủ trả 404).
- Nút "Tạo lại" chỉ ở câu trả lời cuối (tránh làm lệch ngữ cảnh).
- Khóa API chỉ nằm trong bộ nhớ mã hóa của điện thoại; app không ghi log nào.
