# Đăng nhập Google cho EON GPT (làm 1 lần, miễn phí, không cần thẻ)

Mục tiêu: người dùng bấm "Đăng nhập bằng Google" trong app, máy chủ tự nhận tài khoản (không nhập khóa API), mỗi tài khoản tối đa 100 lượt/ngày.

## Thông tin cần dùng
- **Tên gói (package name):** `vn.eon.eon_gpt`
- **SHA-1 (khóa ký cố định có trong zip):** `A7:E0:71:2B:02:35:71:BD:37:2E:FA:67:12:62:6F:4F:E5:73:1F:7F`

## A. Tạo project trên Google Cloud (điện thoại: Chrome > Trang web cho máy tính)
1. Vào console.cloud.google.com, đăng nhập Gmail của bạn, đồng ý điều khoản.
2. Thanh trên cùng bấm chọn project > **Dự án mới** (New project), tên `eon-gpt` > Tạo. Chọn project đó.
3. Menu ☰ > **APIs & Services** > **OAuth consent screen** (hoặc **Google Auth Platform**) > **Get started / Bắt đầu**:
   - App name: `EON GPT`; User support email: Gmail của bạn.
   - Audience: **External** (bên ngoài).
   - Contact email: Gmail của bạn. Đồng ý > Create.
4. Mục **Audience** (Đối tượng) > bấm **Publish app** (Xuất bản ứng dụng) > Confirm. Việc này để **ai có Google cũng đăng nhập được** (nếu để "Testing" thì chỉ những email bạn thêm vào "Test users" mới vào được, tối đa 100). Vì app chỉ xin quyền cơ bản (email), không cần Google duyệt.

## B. Tạo 2 "OAuth client" (mục Clients / Credentials)
1. **Create client** > Application type: **Android**
   - Name: `EON Android`
   - Package name: `vn.eon.eon_gpt`
   - SHA-1: dán dòng SHA-1 ở trên > Create.
2. **Create client** > Application type: **Web application**
   - Name: `EON server`
   - Không cần điền "Authorized redirect URIs" > Create.
   - Copy **Client ID** của cái này (dạng `1234-abcd.apps.googleusercontent.com`). Đây là thứ duy nhất bạn cần.

## C. Đưa Client ID cho máy chủ
- **Kaggle:** Add-ons > Secrets > thêm `GOOGLE_CLIENT_ID` = Client ID Web vừa copy > bật cho notebook.
- **Colab:** chìa khóa (Secrets) > thêm `GOOGLE_CLIENT_ID`, bật Notebook access.
- (Tùy chọn) `EON_ALLOWED_EMAILS` = `a@gmail.com,b@gmail.com` nếu chỉ muốn cho vài email. Bỏ trống = ai cũng dùng được.
- Chạy lại notebook máy chủ bản mới. Log phải có dòng "Đăng nhập Google: BẬT".

## D. Build lại app
1. Trên GitHub: tải **eon_gpt.zip mới** lên repo (đè bản cũ) và dán **build.yml mới** (đè `.github/workflows/build.yml`).
2. Đợi build xong, tải APK. Trong log bước "Dùng khóa ký cố định" phải in ra SHA-1 trùng với SHA-1 ở trên.
3. **Gỡ app EON GPT cũ trước rồi mới cài APK mới** (khóa ký đổi nên Android không cho cài đè; hội thoại lưu trong máy sẽ mất). Từ các lần build sau thì cài đè được bình thường.

## E. Dùng
Mở app > Cài đặt > **Đăng nhập bằng Google** > chọn tài khoản. Hiện email và "Còn x/100 lượt hôm nay" là xong.

## Lỗi hay gặp
- **Mã 10 / DEVELOPER_ERROR:** tên gói hoặc SHA-1 trong OAuth client Android chưa khớp. Kiểm tra lại, chờ vài phút cho Google cập nhật.
- **12500:** chưa điền email hỗ trợ ở màn hình xin phép (bước A.3).
- **"Máy chủ chưa bật đăng nhập Google":** chưa thêm secret `GOOGLE_CLIENT_ID` hoặc đang chạy notebook cũ.
- **403 chưa được cho phép:** email không nằm trong `EON_ALLOWED_EMAILS`.
